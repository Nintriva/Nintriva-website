$(document).ready(function() {
			
		$("#mobile").click(function()
		{
	
			$.scrollTo("#slide1",800,{easing:'easeInOutCirc'})
		});		
		$("#design").click(function()
		{
			$.scrollTo("#slide2",800,{easing:'easeInOutCirc'})
		});
		$("#framework").click(function()
		{
			$.scrollTo("#slide3",800,{easing:'easeInOutCirc'})
		});
		$("#cloud").click(function()
		{
			$.scrollTo("#slide4",800,{easing:'easeInOutCirc'})
		});
		$("#electronics").click(function()
		{
			$.scrollTo("#slide5",800,{easing:'easeInOutCirc'})
		});
	});